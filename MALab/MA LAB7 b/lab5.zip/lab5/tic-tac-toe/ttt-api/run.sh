echo "******Running ttt-api server******"


flask run --host=localhost --port=8083